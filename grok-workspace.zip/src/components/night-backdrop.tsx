const STARS = buildStars(72);

function buildStars(count: number) {
  let seed = 42;
  const next = () => {
    seed = (seed * 16807) % 2147483647;
    return seed / 2147483647;
  };
  return Array.from({ length: count }, (_, index) => ({
    id: index,
    left: next() * 100,
    top: next() * 78,
    size: next() > 0.86 ? 2 : 1,
    opacity: 0.28 + next() * 0.62,
    delay: next() * 6,
    duration: 3.4 + next() * 4.2,
  }));
}

const BLOCKS = [22, 38, 28, 64, 42, 86, 34, 110, 48, 72, 96, 30, 58, 40, 78, 26, 50];

export function NightBackdrop() {
  return (
    <div className="night-backdrop" aria-hidden="true">
      <div className="horizon" />
      <div className="moon" />
      {STARS.map((star) => (
        <span
          key={star.id}
          className="star"
          style={{
            left: `${Math.round(star.left * 100) / 100}%`,
            top: `${Math.round(star.top * 100) / 100}%`,
            width: star.size,
            height: star.size,
            animationDelay: `${star.delay}s`,
            animationDuration: `${star.duration}s`,
            ["--twinkle" as string]: String(star.opacity),
          }}
        />
      ))}
      <div className="skyline">
        {BLOCKS.map((height, index) =>
          index === 8 ? (
            <span key={index} className="obelisk" />
          ) : (
            <span key={index} className="block" style={{ height }} />
          ),
        )}
      </div>
    </div>
  );
}
