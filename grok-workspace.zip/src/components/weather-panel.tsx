import {
  Cloud,
  CloudDrizzle,
  CloudFog,
  CloudLightning,
  CloudMoon,
  CloudRain,
  CloudSnow,
  CloudSun,
  Droplets,
  Moon,
  RefreshCw,
  Sun,
  Sunrise,
  Sunset,
  Thermometer,
  Wind,
  type LucideIcon,
} from "lucide-react";
import {
  conditionLabel,
  formatTemp,
  formatUpdated,
  type HourPoint,
  type Weather,
} from "@/lib/ba-weather";

function iconFor(code: number, isDay: boolean): LucideIcon {
  if (code === 0) return isDay ? Sun : Moon;
  if (code === 1 || code === 2) return isDay ? CloudSun : CloudMoon;
  if (code === 3) return Cloud;
  if (code === 45 || code === 48) return CloudFog;
  if (code >= 51 && code <= 57) return CloudDrizzle;
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return CloudSnow;
  if (code >= 95) return CloudLightning;
  if (code >= 61) return CloudRain;
  return Cloud;
}

function ConditionIcon({
  code,
  isDay,
  className,
}: {
  code: number;
  isDay: boolean;
  className?: string;
}) {
  const Icon = iconFor(code, isDay);
  return <Icon className={className} strokeWidth={1.5} aria-hidden="true" />;
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-line bg-night/70 px-4 py-3">
      <Icon className="size-5 shrink-0 text-amber" strokeWidth={1.5} aria-hidden="true" />
      <div className="min-w-0">
        <p className="text-xs tracking-wide text-mist uppercase">{label}</p>
        <p className="truncate text-base text-ivory tabular-nums">{value}</p>
      </div>
    </div>
  );
}

function hourIsDay(label: string, sunrise: string, sunset: string) {
  return label >= sunrise && label < sunset;
}

function HourCell({ point, day }: { point: HourPoint; day: boolean }) {
  return (
    <div className="flex w-16 shrink-0 flex-col items-center gap-1 rounded-2xl border border-line bg-night/60 px-2 py-3">
      <span className="text-xs text-mist tabular-nums">{point.label}</span>
      <ConditionIcon code={point.code} isDay={day} className="size-4 text-ivory" />
      <span className="text-sm text-ivory tabular-nums">{formatTemp(point.temperature)}°</span>
    </div>
  );
}

export function WeatherPanel({
  weather,
  message,
  loading,
  onRefresh,
}: {
  weather: Weather | null;
  message: string | null;
  loading: boolean;
  onRefresh: () => void;
}) {
  return (
    <section className="min-w-0 rounded-3xl border border-line bg-panel/80 p-6 backdrop-blur-md md:p-8">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs tracking-widest text-amber uppercase">Ciudad Autónoma</p>
          <h2 className="mt-2 font-display text-4xl leading-none text-ivory md:text-5xl">
            Buenos Aires
          </h2>
        </div>
        <button
          type="button"
          onClick={onRefresh}
          disabled={loading}
          className="inline-flex size-11 items-center justify-center rounded-full border border-line text-ivory transition-colors duration-200 hover:border-amber hover:text-amber disabled:opacity-50"
          aria-label="Actualizar temperatura"
        >
          <RefreshCw className={loading ? "size-4 animate-spin" : "size-4"} strokeWidth={1.75} />
        </button>
      </div>

      {weather ? (
        <>
        <div className="mt-8 flex flex-col gap-3 md:flex-row md:items-end md:gap-5" aria-live="polite">
            <p className="font-display text-7xl leading-none text-ivory tabular-nums md:text-8xl">
              {formatTemp(weather.temperature)}
              <span className="text-amber">°</span>
            </p>
            <div className="flex items-center gap-2 text-mist md:mb-2">
              <ConditionIcon code={weather.code} isDay={weather.isDay} className="size-6 text-ivory" />
              <p className="text-base text-ivory">{conditionLabel(weather.code)}</p>
            </div>
          </div>
          <p className="mt-3 text-sm text-mist">
            {weather.isDay ? "De día en la ciudad" : "Noche en la ciudad"}
            {" · "}
            sensación {formatTemp(weather.apparent)}°
            {" · "}
            máx {formatTemp(weather.max)}° · mín {formatTemp(weather.min)}°
          </p>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <Stat icon={Droplets} label="Humedad" value={`${Math.round(weather.humidity)} %`} />
            <Stat icon={Wind} label="Viento" value={`${formatTemp(weather.wind)} km/h`} />
            <Stat icon={Thermometer} label="Lluvia" value={`${formatTemp(weather.precipitation)} mm`} />
            <Stat
              icon={weather.isDay ? Sunset : Sunrise}
              label={weather.isDay ? "Atardecer" : "Amanecer"}
              value={weather.isDay ? weather.sunset : weather.sunrise}
            />
          </div>

          {weather.hourly.length > 0 ? (
            <div className="mt-6">
              <p className="mb-3 text-xs tracking-widest text-mist uppercase">Próximas horas</p>
              <div className="flex gap-2 overflow-x-auto pb-1">
                {weather.hourly.map((point) => (
                  <HourCell
                    key={point.label}
                    point={point}
                    day={hourIsDay(point.label, weather.sunrise, weather.sunset)}
                  />
                ))}
              </div>
            </div>
          ) : null}

          <p className="mt-6 text-xs text-mist">
            Actualizado {formatUpdated(weather.updatedAt)} ART · Open-Meteo
          </p>
        </>
      ) : (
        <div className="mt-8">
          <p className="font-display text-3xl text-ivory">Clima en pausa</p>
          <p className="mt-2 max-w-sm text-base text-pretty text-mist">
            {message ?? "No se pudo leer la temperatura. El reloj sigue en hora de Buenos Aires."}
          </p>
          <button
            type="button"
            onClick={onRefresh}
            disabled={loading}
            className="mt-6 inline-flex h-11 items-center rounded-full bg-amber px-5 text-sm font-medium text-ink disabled:opacity-60"
          >
            Reintentar
          </button>
        </div>
      )}
    </section>
  );
}
