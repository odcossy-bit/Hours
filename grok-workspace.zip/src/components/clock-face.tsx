import { useEffect, useState } from "react";
import { artClock, artDateLabel, pad, type ArtClock } from "@/lib/art-time";

function useArtNow() {
  const [now, setNow] = useState<Date | null>(null);
  const [smooth, setSmooth] = useState(true);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setSmooth(!media.matches);
    apply();
    media.addEventListener("change", apply);

    let frame = 0;
    let timer = 0;
    const tick = () => setNow(new Date());

    if (!media.matches) {
      const loop = () => {
        tick();
        frame = window.requestAnimationFrame(loop);
      };
      frame = window.requestAnimationFrame(loop);
    } else {
      tick();
      timer = window.setInterval(tick, 1000);
    }

    return () => {
      media.removeEventListener("change", apply);
      window.cancelAnimationFrame(frame);
      window.clearInterval(timer);
    };
  }, []);

  return { now, smooth };
}

function handAngles(clock: ArtClock, smooth: boolean) {
  const seconds = clock.seconds + (smooth ? clock.ms / 1000 : 0);
  const minutes = clock.minutes + seconds / 60;
  const hours = (clock.hours % 12) + minutes / 60;
  return {
    hour: hours * 30,
    minute: minutes * 6,
    second: seconds * 6,
  };
}

export function ClockFace() {
  const { now, smooth } = useArtNow();
  const clock = now ? artClock(now) : null;
  const angles = clock ? handAngles(clock, smooth) : null;

  return (
    <div className="flex flex-col items-center">
      <div className="clock-glow relative grid h-72 w-72 place-items-center md:h-96 md:w-96">
        <svg viewBox="0 0 200 200" className="h-full w-full text-ivory">
          <circle cx="100" cy="100" r="97" className="fill-none stroke-line" strokeWidth="1" />
          <circle cx="100" cy="100" r="90" className="fill-none stroke-line" strokeWidth="0.4" />
          {Array.from({ length: 60 }, (_, index) => {
            const major = index % 5 === 0;
            const angle = (index / 60) * Math.PI * 2;
            const inner = major ? 74 : 80;
            const outer = 88;
            const cos = Math.sin(angle);
            const sin = -Math.cos(angle);
            const coord = (value: number) => Math.round(value * 100) / 100;
            return (
              <line
                key={index}
                x1={coord(100 + cos * inner)}
                y1={coord(100 + sin * inner)}
                x2={coord(100 + cos * outer)}
                y2={coord(100 + sin * outer)}
                className={major ? "stroke-ivory" : "stroke-mist"}
                strokeWidth={major ? 1.6 : 0.7}
                strokeLinecap="round"
              />
            );
          })}
          {[
            [12, 0],
            [3, 90],
            [6, 180],
            [9, 270],
          ].map(([label, angle]) => {
            const rad = (angle * Math.PI) / 180;
            const x = 100 + Math.sin(rad) * 60;
            const y = 100 - Math.cos(rad) * 60;
            return (
              <text
                key={label}
                x={x}
                y={y}
                textAnchor="middle"
                dominantBaseline="central"
                className="fill-ivory font-display"
                fontSize="11"
              >
                {label}
              </text>
            );
          })}
          {angles ? (
            <g>
              <g transform={`rotate(${angles.hour} 100 100)`}>
                <line
                  x1="100"
                  y1="108"
                  x2="100"
                  y2="54"
                  className="stroke-ivory"
                  strokeWidth="4"
                  strokeLinecap="round"
                />
              </g>
              <g transform={`rotate(${angles.minute} 100 100)`}>
                <line
                  x1="100"
                  y1="112"
                  x2="100"
                  y2="36"
                  className="stroke-ivory"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                />
              </g>
              <g transform={`rotate(${angles.second} 100 100)`}>
                <line
                  x1="100"
                  y1="118"
                  x2="100"
                  y2="28"
                  className="stroke-amber"
                  strokeWidth="1.1"
                  strokeLinecap="round"
                />
              </g>
              <circle cx="100" cy="100" r="3.2" className="fill-amber" />
            </g>
          ) : null}
        </svg>
      </div>
      <p
        className="mt-2 font-sans text-5xl font-light tabular-nums tracking-tight text-ivory md:text-6xl"
        aria-hidden={!clock}
      >
        {clock ? (
          <>
            {pad(clock.hours)}
            <span className="text-mist">:</span>
            {pad(clock.minutes)}
            <span className="ml-2 align-top text-xl text-amber md:text-2xl">
              {pad(clock.seconds)}
            </span>
          </>
        ) : (
          <span className="text-mist">––:––</span>
        )}
      </p>
      <p className="mt-2 text-base text-mist">{now ? artDateLabel(now) : "Hora de Buenos Aires"}</p>
      {clock ? (
        <p className="sr-only" aria-live="polite">
          {pad(clock.hours)}:{pad(clock.minutes)} en Buenos Aires
        </p>
      ) : null}
    </div>
  );
}
