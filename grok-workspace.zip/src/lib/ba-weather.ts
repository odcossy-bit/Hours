import { createServerFn } from "@tanstack/react-start";

const ENDPOINT =
  "https://api.open-meteo.com/v1/forecast?latitude=-34.6037&longitude=-58.3816" +
  "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,is_day,precipitation" +
  "&hourly=temperature_2m,weather_code" +
  "&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset" +
  "&timezone=America%2FArgentina%2FBuenos_Aires&forecast_days=2";

const ART_SHIFT_MS = 3 * 60 * 60 * 1000;

export type HourPoint = {
  label: string;
  temperature: number;
  code: number;
};

export type Weather = {
  temperature: number;
  apparent: number;
  humidity: number;
  wind: number;
  code: number;
  isDay: boolean;
  precipitation: number;
  max: number;
  min: number;
  sunrise: string;
  sunset: string;
  hourly: HourPoint[];
  updatedAt: string;
};

export type WeatherResult =
  | { ok: true; data: Weather }
  | { ok: false; message: string };

type Forecast = {
  current?: {
    temperature_2m?: number;
    apparent_temperature?: number;
    relative_humidity_2m?: number;
    wind_speed_10m?: number;
    weather_code?: number;
    is_day?: number;
    precipitation?: number;
  };
  hourly?: {
    time?: string[];
    temperature_2m?: number[];
    weather_code?: number[];
  };
  daily?: {
    temperature_2m_max?: number[];
    temperature_2m_min?: number[];
    sunrise?: string[];
    sunset?: string[];
  };
};

function artHourKey(date = new Date()) {
  const shifted = new Date(date.getTime() - ART_SHIFT_MS);
  const y = shifted.getUTCFullYear();
  const m = String(shifted.getUTCMonth() + 1).padStart(2, "0");
  const d = String(shifted.getUTCDate()).padStart(2, "0");
  const h = String(shifted.getUTCHours()).padStart(2, "0");
  return `${y}-${m}-${d}T${h}`;
}

function clockLabel(iso: string) {
  return iso.slice(11, 16);
}

function finite(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function parseForecast(body: Forecast): Weather | null {
  const current = body.current;
  const daily = body.daily;
  if (
    !current ||
    !finite(current.temperature_2m) ||
    !finite(current.apparent_temperature) ||
    !finite(current.relative_humidity_2m) ||
    !finite(current.wind_speed_10m) ||
    !finite(current.weather_code) ||
    !finite(current.precipitation) ||
    !daily ||
    !finite(daily.temperature_2m_max?.[0]) ||
    !finite(daily.temperature_2m_min?.[0]) ||
    typeof daily.sunrise?.[0] !== "string" ||
    typeof daily.sunset?.[0] !== "string"
  ) {
    return null;
  }

  const times = body.hourly?.time ?? [];
  const temps = body.hourly?.temperature_2m ?? [];
  const codes = body.hourly?.weather_code ?? [];
  const key = artHourKey();
  let start = times.findIndex((time) => time.slice(0, 13) === key);
  if (start < 0) start = 0;

  const hourly: HourPoint[] = [];
  for (let i = start; i < times.length && hourly.length < 8; i++) {
    const temperature = temps[i];
    const code = codes[i];
    const time = times[i];
    if (!finite(temperature) || !finite(code) || typeof time !== "string") continue;
    hourly.push({
      label: clockLabel(time),
      temperature,
      code,
    });
  }

  return {
    temperature: current.temperature_2m,
    apparent: current.apparent_temperature,
    humidity: current.relative_humidity_2m,
    wind: current.wind_speed_10m,
    code: current.weather_code,
    isDay: current.is_day === 1,
    precipitation: current.precipitation,
    max: daily.temperature_2m_max[0],
    min: daily.temperature_2m_min[0],
    sunrise: clockLabel(daily.sunrise[0]),
    sunset: clockLabel(daily.sunset[0]),
    hourly,
    updatedAt: new Date().toISOString(),
  };
}

export const getBuenosAiresWeather = createServerFn({ method: "GET" }).handler(
  async (): Promise<WeatherResult> => {
    try {
      const response = await fetch(ENDPOINT, {
        headers: { accept: "application/json" },
        signal: AbortSignal.timeout(8000),
      });
      if (!response.ok) {
        return { ok: false, message: "Open-Meteo no respondió" };
      }
      const body = (await response.json()) as Forecast;
      const data = parseForecast(body);
      if (!data) return { ok: false, message: "El clima llegó incompleto" };
      return { ok: true, data };
    } catch {
      return { ok: false, message: "Sin conexión con el clima de Buenos Aires" };
    }
  },
);

const CONDITIONS: Record<number, string> = {
  0: "Despejado",
  1: "Mayormente despejado",
  2: "Parcialmente nublado",
  3: "Nublado",
  45: "Niebla",
  48: "Niebla helada",
  51: "Llovizna leve",
  53: "Llovizna",
  55: "Llovizna intensa",
  56: "Llovizna helada",
  57: "Llovizna helada fuerte",
  61: "Lluvia leve",
  63: "Lluvia",
  65: "Lluvia fuerte",
  66: "Lluvia helada",
  67: "Lluvia helada fuerte",
  71: "Nieve leve",
  73: "Nieve",
  75: "Nieve fuerte",
  77: "Granos de nieve",
  80: "Chaparrones",
  81: "Chaparrones moderados",
  82: "Chaparrones fuertes",
  85: "Neviscas",
  86: "Neviscas fuertes",
  95: "Tormenta",
  96: "Tormenta con granizo",
  99: "Tormenta fuerte",
};

export function conditionLabel(code: number) {
  return CONDITIONS[code] ?? "Tiempo variable";
}

export function formatTemp(value: number) {
  const rounded = Math.round(value * 10) / 10;
  return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
}

export function formatUpdated(iso: string) {
  return new Intl.DateTimeFormat("es-AR", {
    timeZone: "America/Argentina/Buenos_Aires",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).format(new Date(iso));
}
