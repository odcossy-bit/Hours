const ART_SHIFT_MS = 3 * 60 * 60 * 1000;

export type ArtClock = {
  hours: number;
  minutes: number;
  seconds: number;
  ms: number;
};

/** Argentina keeps a fixed UTC−3 offset (no daylight saving). */
export function artClock(now: Date): ArtClock {
  const shifted = new Date(now.getTime() - ART_SHIFT_MS);
  return {
    hours: shifted.getUTCHours(),
    minutes: shifted.getUTCMinutes(),
    seconds: shifted.getUTCSeconds(),
    ms: shifted.getUTCMilliseconds(),
  };
}

export function artDateLabel(now: Date) {
  const label = new Intl.DateTimeFormat("es-AR", {
    timeZone: "America/Argentina/Buenos_Aires",
    weekday: "long",
    day: "numeric",
    month: "long",
  }).format(now);
  return label.charAt(0).toLocaleUpperCase("es-AR") + label.slice(1);
}

export function pad(value: number) {
  return String(value).padStart(2, "0");
}
