import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ClockFace } from "@/components/clock-face";
import { NightBackdrop } from "@/components/night-backdrop";
import { WeatherPanel } from "@/components/weather-panel";
import { getBuenosAiresWeather, type Weather } from "@/lib/ba-weather";

export const Route = createFileRoute("/")({
  loader: () => getBuenosAiresWeather(),
  component: Home,
});

function Home() {
  const initial = Route.useLoaderData();
  const [weather, setWeather] = useState<Weather | null>(initial.ok ? initial.data : null);
  const [message, setMessage] = useState<string | null>(initial.ok ? null : initial.message);
  const [loading, setLoading] = useState(false);

  async function refresh() {
    setLoading(true);
    try {
      const next = await getBuenosAiresWeather();
      if (next.ok) {
        setWeather(next.data);
        setMessage(null);
      } else {
        setMessage(next.message);
      }
    } catch {
      setMessage("No se pudo actualizar el clima");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const id = window.setInterval(() => {
      void refresh();
    }, 10 * 60 * 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <main className="relative min-h-dvh overflow-x-hidden">
      <NightBackdrop />
      <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-5xl flex-col px-5 pt-8 pb-36 md:px-10 md:pt-12 md:pb-28">
        <header className="max-w-md">
          <p className="text-xs tracking-widest text-amber uppercase">Noche porteña</p>
          <h1 className="mt-3 font-display text-5xl leading-none text-ivory md:text-6xl">
            Reloj de Buenos Aires
          </h1>
          <p className="mt-3 max-w-sm text-base text-pretty text-mist">
            Hora oficial ART y temperatura en vivo del centro de la ciudad, sobre cielo nocturno.
          </p>
        </header>

        <div className="mt-10 grid flex-1 items-center gap-10 md:mt-6 md:grid-cols-[auto_minmax(0,1fr)] md:gap-14">
          <ClockFace />
          <WeatherPanel
            weather={weather}
            message={message}
            loading={loading}
            onRefresh={() => void refresh()}
          />
        </div>

        <footer className="mt-10 flex flex-wrap items-center justify-between gap-3 text-xs text-mist">
          <p>Obelisco · centro</p>
          <p>UTC−3 · sin cambio de horario</p>
        </footer>
      </div>
    </main>
  );
}
