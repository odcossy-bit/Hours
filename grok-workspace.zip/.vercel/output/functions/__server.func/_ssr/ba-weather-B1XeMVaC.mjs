import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ba-weather-B1XeMVaC.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var ENDPOINT = "https://api.open-meteo.com/v1/forecast?latitude=-34.6037&longitude=-58.3816&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,is_day,precipitation&hourly=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,sunrise,sunset&timezone=America%2FArgentina%2FBuenos_Aires&forecast_days=2";
var ART_SHIFT_MS = 108e5;
function artHourKey(date = /* @__PURE__ */ new Date()) {
	const shifted = /* @__PURE__ */ new Date(date.getTime() - ART_SHIFT_MS);
	return `${shifted.getUTCFullYear()}-${String(shifted.getUTCMonth() + 1).padStart(2, "0")}-${String(shifted.getUTCDate()).padStart(2, "0")}T${String(shifted.getUTCHours()).padStart(2, "0")}`;
}
function clockLabel(iso) {
	return iso.slice(11, 16);
}
function finite(value) {
	return typeof value === "number" && Number.isFinite(value);
}
function parseForecast(body) {
	const current = body.current;
	const daily = body.daily;
	if (!current || !finite(current.temperature_2m) || !finite(current.apparent_temperature) || !finite(current.relative_humidity_2m) || !finite(current.wind_speed_10m) || !finite(current.weather_code) || !finite(current.precipitation) || !daily || !finite(daily.temperature_2m_max?.[0]) || !finite(daily.temperature_2m_min?.[0]) || typeof daily.sunrise?.[0] !== "string" || typeof daily.sunset?.[0] !== "string") return null;
	const times = body.hourly?.time ?? [];
	const temps = body.hourly?.temperature_2m ?? [];
	const codes = body.hourly?.weather_code ?? [];
	const key = artHourKey();
	let start = times.findIndex((time) => time.slice(0, 13) === key);
	if (start < 0) start = 0;
	const hourly = [];
	for (let i = start; i < times.length && hourly.length < 8; i++) {
		const temperature = temps[i];
		const code = codes[i];
		const time = times[i];
		if (!finite(temperature) || !finite(code) || typeof time !== "string") continue;
		hourly.push({
			label: clockLabel(time),
			temperature,
			code
		});
	}
	return {
		temperature: current.temperature_2m,
		apparent: current.apparent_temperature,
		humidity: current.relative_humidity_2m,
		wind: current.wind_speed_10m,
		code: current.weather_code,
		isDay: current.is_day === 1,
		precipitation: current.precipitation,
		max: daily.temperature_2m_max[0],
		min: daily.temperature_2m_min[0],
		sunrise: clockLabel(daily.sunrise[0]),
		sunset: clockLabel(daily.sunset[0]),
		hourly,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
var getBuenosAiresWeather_createServerFn_handler = createServerRpc({
	id: "93ac0acf9dda6006b927a855650d37ed151deb82187e11fca156c9eccda8b592",
	name: "getBuenosAiresWeather",
	filename: "src/lib/ba-weather.ts"
}, (opts) => getBuenosAiresWeather.__executeServer(opts));
var getBuenosAiresWeather = createServerFn({ method: "GET" }).handler(getBuenosAiresWeather_createServerFn_handler, async () => {
	try {
		const response = await fetch(ENDPOINT, {
			headers: { accept: "application/json" },
			signal: AbortSignal.timeout(8e3)
		});
		if (!response.ok) return {
			ok: false,
			message: "Open-Meteo no respondió"
		};
		const data = parseForecast(await response.json());
		if (!data) return {
			ok: false,
			message: "El clima llegó incompleto"
		};
		return {
			ok: true,
			data
		};
	} catch {
		return {
			ok: false,
			message: "Sin conexión con el clima de Buenos Aires"
		};
	}
});
//#endregion
export { getBuenosAiresWeather_createServerFn_handler };
