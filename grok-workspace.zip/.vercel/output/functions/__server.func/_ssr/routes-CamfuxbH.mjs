import { i as __toESM } from "../_runtime.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as CloudDrizzle, a as Sunrise, c as Moon, d as CloudSun, f as CloudSnow, g as CloudFog, h as CloudLightning, i as Sunset, l as Droplets, m as CloudMoon, o as Sun, p as CloudRain, r as Thermometer, s as RefreshCw, t as Wind, u as Cloud } from "../_libs/lucide-react.mjs";
import { a as formatUpdated, i as formatTemp, n as Route, o as getBuenosAiresWeather, r as conditionLabel } from "./router-Dc_uYhwO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CamfuxbH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ART_SHIFT_MS = 108e5;
/** Argentina keeps a fixed UTC−3 offset (no daylight saving). */
function artClock(now) {
	const shifted = /* @__PURE__ */ new Date(now.getTime() - ART_SHIFT_MS);
	return {
		hours: shifted.getUTCHours(),
		minutes: shifted.getUTCMinutes(),
		seconds: shifted.getUTCSeconds(),
		ms: shifted.getUTCMilliseconds()
	};
}
function artDateLabel(now) {
	const label = new Intl.DateTimeFormat("es-AR", {
		timeZone: "America/Argentina/Buenos_Aires",
		weekday: "long",
		day: "numeric",
		month: "long"
	}).format(now);
	return label.charAt(0).toLocaleUpperCase("es-AR") + label.slice(1);
}
function pad(value) {
	return String(value).padStart(2, "0");
}
function useArtNow() {
	const [now, setNow] = (0, import_react.useState)(null);
	const [smooth, setSmooth] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const media = window.matchMedia("(prefers-reduced-motion: reduce)");
		const apply = () => setSmooth(!media.matches);
		apply();
		media.addEventListener("change", apply);
		let frame = 0;
		let timer = 0;
		const tick = () => setNow(/* @__PURE__ */ new Date());
		if (!media.matches) {
			const loop = () => {
				tick();
				frame = window.requestAnimationFrame(loop);
			};
			frame = window.requestAnimationFrame(loop);
		} else {
			tick();
			timer = window.setInterval(tick, 1e3);
		}
		return () => {
			media.removeEventListener("change", apply);
			window.cancelAnimationFrame(frame);
			window.clearInterval(timer);
		};
	}, []);
	return {
		now,
		smooth
	};
}
function handAngles(clock, smooth) {
	const seconds = clock.seconds + (smooth ? clock.ms / 1e3 : 0);
	const minutes = clock.minutes + seconds / 60;
	return {
		hour: (clock.hours % 12 + minutes / 60) * 30,
		minute: minutes * 6,
		second: seconds * 6
	};
}
function ClockFace() {
	const { now, smooth } = useArtNow();
	const clock = now ? artClock(now) : null;
	const angles = clock ? handAngles(clock, smooth) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "clock-glow relative grid h-72 w-72 place-items-center md:h-96 md:w-96",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 200 200",
					className: "h-full w-full text-ivory",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "97",
							className: "fill-none stroke-line",
							strokeWidth: "1"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "100",
							cy: "100",
							r: "90",
							className: "fill-none stroke-line",
							strokeWidth: "0.4"
						}),
						Array.from({ length: 60 }, (_, index) => {
							const major = index % 5 === 0;
							const angle = index / 60 * Math.PI * 2;
							const inner = major ? 74 : 80;
							const outer = 88;
							const cos = Math.sin(angle);
							const sin = -Math.cos(angle);
							const coord = (value) => Math.round(value * 100) / 100;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
								x1: coord(100 + cos * inner),
								y1: coord(100 + sin * inner),
								x2: coord(100 + cos * outer),
								y2: coord(100 + sin * outer),
								className: major ? "stroke-ivory" : "stroke-mist",
								strokeWidth: major ? 1.6 : .7,
								strokeLinecap: "round"
							}, index);
						}),
						[
							[12, 0],
							[3, 90],
							[6, 180],
							[9, 270]
						].map(([label, angle]) => {
							const rad = angle * Math.PI / 180;
							const x = 100 + Math.sin(rad) * 60;
							const y = 100 - Math.cos(rad) * 60;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
								x,
								y,
								textAnchor: "middle",
								dominantBaseline: "central",
								className: "fill-ivory font-display",
								fontSize: "11",
								children: label
							}, label);
						}),
						angles ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
								transform: `rotate(${angles.hour} 100 100)`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "100",
									y1: "108",
									x2: "100",
									y2: "54",
									className: "stroke-ivory",
									strokeWidth: "4",
									strokeLinecap: "round"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
								transform: `rotate(${angles.minute} 100 100)`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "100",
									y1: "112",
									x2: "100",
									y2: "36",
									className: "stroke-ivory",
									strokeWidth: "2.4",
									strokeLinecap: "round"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
								transform: `rotate(${angles.second} 100 100)`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
									x1: "100",
									y1: "118",
									x2: "100",
									y2: "28",
									className: "stroke-amber",
									strokeWidth: "1.1",
									strokeLinecap: "round"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "100",
								cy: "100",
								r: "3.2",
								className: "fill-amber"
							})
						] }) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-sans text-5xl font-light tabular-nums tracking-tight text-ivory md:text-6xl",
				"aria-hidden": !clock,
				children: clock ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					pad(clock.hours),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-mist",
						children: ":"
					}),
					pad(clock.minutes),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 align-top text-xl text-amber md:text-2xl",
						children: pad(clock.seconds)
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-mist",
					children: "––:––"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-base text-mist",
				children: now ? artDateLabel(now) : "Hora de Buenos Aires"
			}),
			clock ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: [
					pad(clock.hours),
					":",
					pad(clock.minutes),
					" en Buenos Aires"
				]
			}) : null
		]
	});
}
var STARS = buildStars(72);
function buildStars(count) {
	let seed = 42;
	const next = () => {
		seed = seed * 16807 % 2147483647;
		return seed / 2147483647;
	};
	return Array.from({ length: count }, (_, index) => ({
		id: index,
		left: next() * 100,
		top: next() * 78,
		size: next() > .86 ? 2 : 1,
		opacity: .28 + next() * .62,
		delay: next() * 6,
		duration: 3.4 + next() * 4.2
	}));
}
var BLOCKS = [
	22,
	38,
	28,
	64,
	42,
	86,
	34,
	110,
	48,
	72,
	96,
	30,
	58,
	40,
	78,
	26,
	50
];
function NightBackdrop() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "night-backdrop",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "horizon" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "moon" }),
			STARS.map((star) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "star",
				style: {
					left: `${Math.round(star.left * 100) / 100}%`,
					top: `${Math.round(star.top * 100) / 100}%`,
					width: star.size,
					height: star.size,
					animationDelay: `${star.delay}s`,
					animationDuration: `${star.duration}s`,
					["--twinkle"]: String(star.opacity)
				}
			}, star.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "skyline",
				children: BLOCKS.map((height, index) => index === 8 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "obelisk" }, index) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block",
					style: { height }
				}, index))
			})
		]
	});
}
function iconFor(code, isDay) {
	if (code === 0) return isDay ? Sun : Moon;
	if (code === 1 || code === 2) return isDay ? CloudSun : CloudMoon;
	if (code === 3) return Cloud;
	if (code === 45 || code === 48) return CloudFog;
	if (code >= 51 && code <= 57) return CloudDrizzle;
	if (code >= 71 && code <= 77 || code === 85 || code === 86) return CloudSnow;
	if (code >= 95) return CloudLightning;
	if (code >= 61) return CloudRain;
	return Cloud;
}
function ConditionIcon({ code, isDay, className }) {
	const Icon = iconFor(code, isDay);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className,
		strokeWidth: 1.5,
		"aria-hidden": "true"
	});
}
function Stat({ icon: Icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 rounded-2xl border border-line bg-night/70 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5 shrink-0 text-amber",
			strokeWidth: 1.5,
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-wide text-mist uppercase",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-base text-ivory tabular-nums",
				children: value
			})]
		})]
	});
}
function hourIsDay(label, sunrise, sunset) {
	return label >= sunrise && label < sunset;
}
function HourCell({ point, day }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex w-16 shrink-0 flex-col items-center gap-1 rounded-2xl border border-line bg-night/60 px-2 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-mist tabular-nums",
				children: point.label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConditionIcon, {
				code: point.code,
				isDay: day,
				className: "size-4 text-ivory"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm text-ivory tabular-nums",
				children: [formatTemp(point.temperature), "°"]
			})
		]
	});
}
function WeatherPanel({ weather, message, loading, onRefresh }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "min-w-0 rounded-3xl border border-line bg-panel/80 p-6 backdrop-blur-md md:p-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-amber uppercase",
				children: "Ciudad Autónoma"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-display text-4xl leading-none text-ivory md:text-5xl",
				children: "Buenos Aires"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onRefresh,
				disabled: loading,
				className: "inline-flex size-11 items-center justify-center rounded-full border border-line text-ivory transition-colors duration-200 hover:border-amber hover:text-amber disabled:opacity-50",
				"aria-label": "Actualizar temperatura",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
					className: loading ? "size-4 animate-spin" : "size-4",
					strokeWidth: 1.75
				})
			})]
		}), weather ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-3 md:flex-row md:items-end md:gap-5",
				"aria-live": "polite",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-7xl leading-none text-ivory tabular-nums md:text-8xl",
					children: [formatTemp(weather.temperature), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-amber",
						children: "°"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-mist md:mb-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConditionIcon, {
						code: weather.code,
						isDay: weather.isDay,
						className: "size-6 text-ivory"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base text-ivory",
						children: conditionLabel(weather.code)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-mist",
				children: [
					weather.isDay ? "De día en la ciudad" : "Noche en la ciudad",
					" · ",
					"sensación ",
					formatTemp(weather.apparent),
					"°",
					" · ",
					"máx ",
					formatTemp(weather.max),
					"° · mín ",
					formatTemp(weather.min),
					"°"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: Droplets,
						label: "Humedad",
						value: `${Math.round(weather.humidity)} %`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: Wind,
						label: "Viento",
						value: `${formatTemp(weather.wind)} km/h`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: Thermometer,
						label: "Lluvia",
						value: `${formatTemp(weather.precipitation)} mm`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: weather.isDay ? Sunset : Sunrise,
						label: weather.isDay ? "Atardecer" : "Amanecer",
						value: weather.isDay ? weather.sunset : weather.sunrise
					})
				]
			}),
			weather.hourly.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs tracking-widest text-mist uppercase",
					children: "Próximas horas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto pb-1",
					children: weather.hourly.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HourCell, {
						point,
						day: hourIsDay(point.label, weather.sunrise, weather.sunset)
					}, point.label))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-xs text-mist",
				children: [
					"Actualizado ",
					formatUpdated(weather.updatedAt),
					" ART · Open-Meteo"
				]
			})
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl text-ivory",
					children: "Clima en pausa"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-sm text-base text-pretty text-mist",
					children: message ?? "No se pudo leer la temperatura. El reloj sigue en hora de Buenos Aires."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onRefresh,
					disabled: loading,
					className: "mt-6 inline-flex h-11 items-center rounded-full bg-amber px-5 text-sm font-medium text-ink disabled:opacity-60",
					children: "Reintentar"
				})
			]
		})]
	});
}
function Home() {
	const initial = Route.useLoaderData();
	const [weather, setWeather] = (0, import_react.useState)(initial.ok ? initial.data : null);
	const [message, setMessage] = (0, import_react.useState)(initial.ok ? null : initial.message);
	const [loading, setLoading] = (0, import_react.useState)(false);
	async function refresh() {
		setLoading(true);
		try {
			const next = await getBuenosAiresWeather();
			if (next.ok) {
				setWeather(next.data);
				setMessage(null);
			} else setMessage(next.message);
		} catch {
			setMessage("No se pudo actualizar el clima");
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => {
			refresh();
		}, 6e5);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-dvh overflow-x-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NightBackdrop, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative z-10 mx-auto flex min-h-dvh w-full max-w-5xl flex-col px-5 pt-8 pb-36 md:px-10 md:pt-12 md:pb-28",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-amber uppercase",
							children: "Noche porteña"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 font-display text-5xl leading-none text-ivory md:text-6xl",
							children: "Reloj de Buenos Aires"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-sm text-base text-pretty text-mist",
							children: "Hora oficial ART y temperatura en vivo del centro de la ciudad, sobre cielo nocturno."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 grid flex-1 items-center gap-10 md:mt-6 md:grid-cols-[auto_minmax(0,1fr)] md:gap-14",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockFace, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherPanel, {
						weather,
						message,
						loading,
						onRefresh: () => void refresh()
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "mt-10 flex flex-wrap items-center justify-between gap-3 text-xs text-mist",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Obelisco · centro" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "UTC−3 · sin cambio de horario" })]
				})
			]
		})]
	});
}
//#endregion
export { Home as component };
